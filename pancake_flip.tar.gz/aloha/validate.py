"""Tests to ensure that piper-cahed MJX models are up-to-date."""

import difflib
import subprocess
import tempfile

from absl.testing import absltest

from google3.pyglib import resources


class ValidateMJXPatch(absltest.TestCase):
  """Tests to ensure that generated mjx models up-to-date."""

  def test_mjx_models_are_up_to_date(self):
    """Compares mjx models in google3 with the generated version."""
    files = ['aloha', 'scene', 'integrated_cartesian_actuators']
    for name in files:
      piper_orig_path = (
          f'google3/third_party/mujoco_menagerie/aloha/{name}.xml'
      )
      piper_mjx_path = (
          f'google3/third_party/mujoco_menagerie/aloha/mjx_{name}.xml'
      )
      patch_path = (
          f'google3/third_party/mujoco_menagerie/aloha/mjx_{name}.patch'
      )

      tmp = tempfile.NamedTemporaryFile('w+t')
      piper_orig_file = resources.GetResourceFilename(piper_orig_path, 'r')
      patch_file = resources.GetResourceFilename(patch_path, 'r')
      patch_args = ['patch', '-p0', '-o', tmp.name, piper_orig_file, patch_file]
      subprocess.run(args=patch_args, check=True)
      generated_mjx_xml = tmp.read()
      # compare result to piper version
      piper_mjx_xml = resources.GetResource(piper_mjx_path, 'r')
      # Not using assertEqual since we don't want to print out entire files
      # when they don't match.
      if piper_mjx_xml != generated_mjx_xml:
        msg = f"""
  The cached content in mjx_{name}.xml doesn't match the content of the respective base model and patch file, which serve as source of truth.
  You need to ensure your changes are reflected in either the base model or the patch file, and update the piper cache mjx_{name}.xml with the generated model.
  Difference:\n""" + ''.join(difflib.ndiff(piper_mjx_xml, generated_mjx_xml))
        self.fail(msg.strip())


if __name__ == '__main__':
  absltest.main()
